import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top-navbar-bottom',
  templateUrl: './top-navbar-bottom.component.html',
  styleUrls: ['./top-navbar-bottom.component.scss']
})
export class TopNavbarBottomComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
